<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
//trang chu
Route::get('index',['as' => 'trang-chu','uses' =>'PageController@getIndex']);

//loai san pham
Route::get('loaisanpham/{type}',['as' => 'loaisanpham','uses' =>'PageController@getLoaiSp']);

Route::get('chitietsanpham/{id}',['as' => 'chitietsanpham','uses' =>'PageController@getChitiet']);

Route::get('lienhe',['as' => 'lienhe','uses' =>'PageController@getLienhe']);

//
Route::get('gioithieu',['as' => 'gioithieu','uses' =>'PageController@getGioithieu']);

//gio hang
Route::get('add-to-cart/{id}',[
	'as' =>'themgiohang',
	'uses'=>'PageController@getAddToCart'			
]);

//xoa
Route::get('delete-to-cart/{id}',[
	'as' =>'xoagiohang',
	'uses'=>'PageController@getDelItemCart'			
]);

 // luu thong tin khach hang
Route::get('dat-hang',[             
	'as' =>'dathang',           
    'uses'=>'PageController@getDathang'            
]);         
Route::post('dat-hang',[                
    'as'=>'postdathang',            
    'uses'=>'PageController@postDathang'           
]);         
              
