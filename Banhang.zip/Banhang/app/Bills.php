<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bills extends Model
{
    protected $table = 'bills';
     public function Bill_products(){
        return $this->beLongsTo('App\Bills','id_type','id');
    }
}
