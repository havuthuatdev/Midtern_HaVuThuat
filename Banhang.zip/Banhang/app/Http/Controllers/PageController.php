<?php

namespace App\Http\Controllers;
use App\Slide;
use App\Product;
use App\Cart;
use App\Bills;
use App\BillDetail;
use App\Customer;
use App\productType;
use Illuminate\Http\Request;
use Session;


class PageController extends Controller
{
    public function getIndex(){
    	$slide = Slide::all();
    	// $new_product = Product::where('new',1)->get(); // get() hiển thị tất cả sản phẩm có trong table
    	$new_product = Product::where('new',1)->paginate(8); // paginate(8) hiển thị số phần tử có trong table: vidu: 8 sản phẩm => mục đích để hiển thị số sản phẩm trong 1 trang 
    	$promotion_product = Product::where('promotion_price','<>',0)->paginate(4);

    	return view('page.trangchu',compact('slide','new_product','promotion_product'));
    }

    public function getLoaiSp($type){
    	//return view('page.loai_sanpham');

        //Lay san pham hien thi theoloai						
        $sp_theoloai= Product::where('id_type',$type) ->limit(3)->get();						
						
       // Lay san pham hien thi Khac <> loai						
        $sp_khac= Product::where('id_type','<>',$type)->limit(3)->get();						
						
        // Lay san pham hien thi theoloai typeproduct  cho menu ben trai	
        $loai = ProductType::all();	
         // Lay ten Loai san pham moi khi chung ta chon danh muc loai san pham(phan menu ben trai)									
         $loai_sp = ProductType::where('id',$type)->first();
         // echo json_encode($loai);									
									
    	return view('page.loai_sanpham',compact('sp_theoloai','sp_khac','loai','loai_sp'));													
    }
    //them vao gio hang
    public function getAddToCart(Request $req, $id){
        $product = Product::find($id);
        $oldCart = Session('cart')?Session::get('cart'):null;               
        $cart = new Cart($oldCart);             
        $cart->add($product,$id);               
        $req->session()->put('cart', $cart);                
        return redirect()->back();              
    }

        // xoa san pham trong gio hang
      public function getDelItemCart($id){              
        $oldCart = Session::has('cart')?Session::get('cart'):null;              
        $cart = new Cart($oldCart);             
        $cart->removeItem($id);             
        if(count($cart->items)>0){              
        Session::put('cart',$cart);         
        }               
        else{               
            Session::forget('cart');                
        }               
        return redirect()->back();              
    }               


    public function getChitiet(Request $rqe){
        $sanpham = Product::where('id',$rqe->id)->first();

        $sp_tuongtu =Product::where('id_type',$sanpham->id_type)->paginate(3);
    	return view('page.chitiet_sanpham',compact('sanpham','sp_tuongtu'));
    }
   //luu thong tin khach hang
    function getDatHang() {
        $oldCart = Session::get('cart');
       $cart = new Cart($oldCart);
       return view('page.dathang')->with(['cart','product_cart'=>$cart->items,
       'totalPrice'=>$cart->totalPrice,'totalQty'=>$cart->totalQty]);
   }
    
    function postDatHang(Request $req) {
        $cart = Session::get('cart');

        $customer = new Customer;
        $customer->name = $req->name;
        $customer->gender = $req->gender;
        $customer->email = $req->email;
        $customer->address = $req->address;
        $customer->phone_number = $req->phone;
        $customer->note = $req->notes;
        $customer->save();

        $bill = new Bills;
        $bill->id_customer = $customer->id;
        $bill->date_order = date('Y-m-d');
        $bill->total = $cart->totalPrice;
        $bill->payment = $req->payment_method;
        $bill->note = $req->notes;
        $bill->save();

        foreach ($cart->items as $key => $value) {
            $bill_detail = new BillDetail;
            $bill_detail->id_bill = $bill->id;
            $bill_detail->id_product = $key;
            $bill_detail->quantity = $value['qty'];
            $bill_detail->unit_price = ($value['price']/$value['qty']);
            $bill_detail->save();
        }
        Session::forget('cart');
        return redirect()->back()->with('thongbao','Đặt hàng thành công');
    } 

    public function getLienhe(){
    	return view('page.lienhe');
    }
    public function getGioithieu(){
    	return view('page.about');
    }


}
